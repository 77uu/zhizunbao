<?php
wpjam_include_sms_provider(wpjam_sms_get_setting('sms_provider'), 'domestic', true);
wpjam_include_sms_provider(wpjam_sms_get_setting('international_sms_provider'), 'international', true);