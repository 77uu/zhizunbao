<?php

include WPJAM_SIGNUP_PLUGIN_DIR . 'api/sms.code.verify.php';