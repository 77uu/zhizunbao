<?php

wp_logout();

wpjam_send_json();